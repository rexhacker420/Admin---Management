
<!-- header.php -->
<div class="row shadow bg-dark text-white " style="position: sticky; top: 0; z-index: 2;">
    <section class="d-flex justify-content-left mb-3 mx-auto w-30 p-2 rounded-1 fs-5 mt-5 text-center hackingSection">
        <div class="project-title text-center mx-auto">
            <span style="/* border: 2px solid white; */
            font-size: 1.8rem;
            font-weight: 900;
            font-family: arial;
            text-shadow: 0 0 3rem rgb(0, 255, 0);
            color: rgb(3, 231, 3);
            cursor: none;">HACKING DASHBORD <br><span style="/* border: 2px solid white; */
            font-size: 0.9rem;
            position: relative;
            top: -1.5rem;
            left: 7rem;
            font-weight: 900;
            font-family: Sans-serif;
            text-shadow: 0 0 3rem rgb(0, 255, 0);
            color: rgb(3, 231, 3);
            cursor: none;">- sanjeet kalyan</span></span>
        </div>
    </section>

    <div class="col-16 ">
        <ul class="nav justify-content-center py-2">
            <li class="nav-item"><a
                    class="nav-link <?php echo basename($_SERVER['PHP_SELF']) == 'dashboard.php' ? '.active-link' : 'text-white'; ?>"
                    href="dashboard.php">Dashboard</a></li>
            <li class="nav-item"><a
                    class="nav-link <?php echo basename($_SERVER['PHP_SELF']) == 'target.php' ? 'active-link' : 'text-white'; ?>"
                    href="target.php">Targets</a></li>
            <li class="nav-item">
                <a class="nav-link <?php echo basename($_SERVER['PHP_SELF']) == 'about.php' ? 'active-link' : 'text-white'; ?>"
                    href="about.php">About</a>
            </li>
            <li class="nav-item">
                <a class="nav-link <?php echo basename($_SERVER['PHP_SELF']) == 'setting.php' ? 'active-link' : 'text-white'; ?>"
                    href="setting.php">Setting</a>
            </li>
            <li class="nav-item">
                <a class=" btn btn-danger btn-sm nav-link <?php echo basename($_SERVER['PHP_SELF']) == 'logout.php' ? 'active-link' : 'text-white'; ?>"
                    href="logout.php">Logout</a>
            </li>
        </ul>
    </div>
    <div class="col-12 text-center text-secondary pt-2 small " style="position: fixed; bottom: 0.4rem;text-shadow: 0 0 30px black; cursor: none;" id="developer">
        Developer ❤️ by Sanjeet Kalyan
    </div>
</div>